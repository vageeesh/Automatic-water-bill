import React, {Component} from 'react';

class DisplayBill extends Component {
  render() {
    return (
      <div className="App">
        <h1> HIIIIIIIIIIIIIIIIIIIII!!!!!!!!!!!!!!!!</h1>
      </div>
    );
  }
}
  export default DisplayBill;
