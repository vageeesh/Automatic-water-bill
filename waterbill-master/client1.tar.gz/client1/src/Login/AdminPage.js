import React, { Component } from 'react';

import { Table, Button  } from 'reactstrap';

import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem } from 'reactstrap';

class AdminPage extends Component {

  constructor(props) {
    super(props);
      this.state = {
        isLoding: true,
        isOpen: false,
        Cust_id: ''
      };

  }

  render() {
    return (
      <div className="adminpage">
      <Navbar style={{backgroundColor: "#E4BC79"}} light expand="md">
  <NavbarBrand href="/" style = {{width : 150, marginLeft : 480, color: "#840101" }}>Easy Water Bill Payment </NavbarBrand>
  <NavbarToggler onClick={this.toggle} />
  <Collapse isOpen={this.state.isOpen} navbar>
    <Nav className="ml-auto" navbar>

      <UncontrolledDropdown nav inNavbar>
        <DropdownToggle nav caret>
          Options
        </DropdownToggle>
        <DropdownMenu right>
          <DropdownItem>
            About
          </DropdownItem>
          <DropdownItem>
            Help
          </DropdownItem>
          <DropdownItem divider />
          <DropdownItem>
            Reset
          </DropdownItem>
        </DropdownMenu>
      </UncontrolledDropdown>
    </Nav>
  </Collapse>
</Navbar>

<Table hover>
    <thead>
      <tr>
        <th>#</th>
        <th>Customer id</th>
        <th>DELETE</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Mark</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <th scope="row">2</th>
        <td>Jacob</td>
        <td>Thornton</td>
        <td>@fat</td>
      </tr>
      <tr>
        <th scope="row">3</th>
        <td>Larry</td>
        <td>the Bird</td>
        <td>@twitter</td>
      </tr>

      {this.state.wateruse.map((item, idx) => (
                  <tr id="addr0" key={idx}>
                    <td>{idx}</td>
                    <td>
                      {this.state.wateruse[idx]._id}
                    </td>
                    <td>
                      {this.state.wateruse[idx].amount}

                    </td>
                    <td>
                      {this.state.wateruse[idx].date}


                    </td>
                  </tr>
                ))}

    </tbody>
  </Table>

      <Button color="primary" style = {{width : 150, marginLeft : 100, marginTop: 200}}>ADD USER</Button>{' '}

      <Button color="primary" style = {{width : 150, marginLeft :750, marginTop: 200 }}>DELETE USER</Button>{' '}
      </div>

    );
  }
}
export default AdminPage;
