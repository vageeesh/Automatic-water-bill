import React, {Component} from 'react';
import Userlogin from './Userlogin'

import { Route, Redirect } from 'react-router'

import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';

import PropTypes from 'prop-types';

// Be sure to include styles at some point, probably during your bootstraping
import '@trendmicro/react-sidenav/dist/react-sidenav.css';

import { Table, Button  } from 'reactstrap';

class Testing2 extends Component {

  constructor(props) {
    super(props);



      console.log('props',this.props);
      this.state = {
        islog: true,
        message: 'wel',
        expanded: false,
        selected_month:1,
        user_retrieved_array: [],
        user_retrieved_array1:[]
      }

      this.handleClickOutside = this.handleClickOutside.bind(this);


    }

    onSelectedMonth(val) {
      console.log("selected month",val);
      this.setState({
          selected_month: val,
      });
      fetch('/customer/retrieve',
      {
        method: 'POST',
        headers: {
          'Content-Type':'application/json',
        },
        body: JSON.stringify({
          cid : "c311",
          amount: "67",
          year : "2017",
          month: val,
          date: "2017/5/4"
        }),

      }).then(res=>res.json())
        .then(result=> {
          console.log('fetched_array is',result);
          if(result.dat!=null) {
           console.log("result is"+result);

            this.setState({
            user_retrieved_array: result.wateruse.dailyusage,
            })
            console.log('fetched_array_result',this.state.user_retrieved_array[0].usebyday);
            this.setState({
            user_retrieved_array1: this.state.user_retrieved_array[0].usebyday,
          })
          }
          else {
            this.setState({
              user_retrieved_array1: [],
              message: "No data to display",

            })
          }
        });
    }

    componentDidMount() {

       //document.addEventListener('mousedown', this.handleClickOutside);
    }

    componentWillMount(){
        this.onSelectedMonth(1);

      }
      handleClickOutside(event) {
            this.setState({ expanded: false });
        }


  render() {

    const {
    islog
    } = this.state;


    return (

      <div>
          <SideNav

              onSelect={(selected,key) => {
                  // Add your code here
                  console.log(selected);
                  this.onSelectedMonth(selected);
              }}
              expanded={this.state.expanded}
              onToggle={(expanded) => {
                  this.setState({ expanded });
                }}
          >
<SideNav.Toggle />
<SideNav.Nav defaultSelected="1">
  <NavItem eventKey="1" onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          Janaury
      </NavText>
  </NavItem>
  <NavItem eventKey="2"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          Febrary
      </NavText>
  </NavItem>
  <NavItem eventKey="3"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          March
      </NavText>
  </NavItem>
  <NavItem eventKey="4"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          April
      </NavText>
  </NavItem>
  <NavItem eventKey="5"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          May
      </NavText>
  </NavItem>
  <NavItem eventKey="6"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          June
      </NavText>
  </NavItem>
  <NavItem eventKey="7"  onClick={this.handleClickOutside}>
      <NavIcon>
          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
      </NavIcon>
      <NavText>
          July
      </NavText>
  </NavItem>
  <NavItem eventKey="8"  onClick={this.handleClickOutside}>
  <NavIcon>
             <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} />
         </NavIcon>
      <NavText>
          August
      </NavText>
  </NavItem>
</SideNav.Nav>
</SideNav>


<Table hover>
    <thead>
      <tr>
        <th>#</th>
        <th>Customer id</th>
        <th>Water Usage</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>


      {this.state.user_retrieved_array1.map((item,idx) => (
                  <tr id="addr0" key={idx}>
                    <td>{idx}</td>
                    <td>
                      {item._id}
                    </td>
                    <td>
                      {item.amount}

                    </td>
                    <td>
                      {item.date}


                    </td>
                  </tr>
                ))}

    </tbody>
  </Table>

        <center><Button color="primary">Pay My Bill</Button>{' '} </center>

      </div>

    );
  }

}

export default Testing2;
